# Code for the Next Energy article (label-free SOH error)

Same code as the Colab notebook `NE_Colab_notebook.ipynb`.

```
pip install -r requirements.txt
python run_all.py
```

The versions in `requirements.txt` are the ones that produced the article's tables. Other versions of
numpy, pandas, scipy or scikit-learn give slightly different numbers.

Put `nasa_cycle_features.csv` (and optionally `GMP.csv`) in `data/` first.

Figures are saved under the article numbering, in `figures/` and `figures/NextEnergy/`:

| File | Article figure |
|---|---|
| Figure_1.png | Fig. 1 study design |
| Figure_2.png | Fig. 2 unseen-domain error |
| Figure_3.png | Fig. 3 certificate |
| Figure_4.png | Fig. 4 GMP known truth |
| Figure_5.png | Fig. 5 conformal error bounds |
| Figure_6.png | Fig. 6 reference capacity checks |
| Figure_7.png | Fig. 7 explainability |
| Figure_8.png | Fig. 8 generalizability |
| Figure_S1.png | Fig. S1 reliability |

`not_in_paper_warning_signals.png` and `not_in_paper_offline_check_placements.png` are extra plots
whose values are in Table 5 and Table S4; they are not in the article.
